# S2DO Architectural LAB

A single-page architectural portfolio website with a black/white/gray luxury editorial aesthetic.

## Run
Open `index.html` in any modern browser.

## Customize
- Replace the four project image backgrounds in `.p1`–`.p4` with real project images.
- Update project names, descriptions and metadata in `index.html`.
- Replace the email and Instagram placeholders in the Contact section.
- For production, deploy the folder to GitHub Pages, Netlify, Vercel or another static host.
